package com.tmptoto.Controller.Common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tmptoto.Data.Common.LoginRequestDTO;
import com.tmptoto.Data.Common.LoginResponseDTO;
import com.tmptoto.Service.Common.LoginService;

@RestController
public class LoginController 
{
	
	@Autowired
	private LoginService loginService;

	@RequestMapping(value = "/common/login")
	public LoginResponseDTO login(@RequestBody final LoginRequestDTO inDTO)
	{
		LoginResponseDTO test = new LoginResponseDTO();
		
		String a = inDTO.getInputId();
		String b = inDTO.getInputPw();
		
		System.out.println(a);
		System.out.println(b);
		
		test.setCode("셋코드");
		test.setMsg("마사지");
		
		//sl4j
		Logger logger = LoggerFactory.getLogger("com.tmptoto.Controller.Common");
		logger.debug(b);
		
		loginService.login(a);
		
		return test;
	}
	
}
