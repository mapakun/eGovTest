package com.tmptoto.Controller.Common;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class HelloController {
	
	@RequestMapping(value = "/api/hello", method = RequestMethod.GET)
    public List<String> Hello(){
        return Arrays.asList("처음으로", "받습니당");
    }

}
