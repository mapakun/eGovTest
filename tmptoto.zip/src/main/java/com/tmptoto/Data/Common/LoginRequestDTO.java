package com.tmptoto.Data.Common;

public class LoginRequestDTO 
{
	private String inputId;
	private String inputPw;
	
	public String getInputId() {
		return inputId;
	}
	public void setInputId(String inputId) {
		this.inputId = inputId;
	}
	public String getInputPw() {
		return inputPw;
	}
	public void setInputPw(String inputPw) {
		this.inputPw = inputPw;
	}
	
	
}
