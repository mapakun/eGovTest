package com.tmptoto.Service.Common;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tmptoto.Data.Common.LoginResponseDTO;
import com.tmptoto.Mapper.Common.LoginMapper;

@Service
public class LoginService 
{
	@Autowired
	private LoginMapper loginMapper;
	
	public LoginResponseDTO login(String inDTO)
	{
		LoginResponseDTO test = new LoginResponseDTO();
		
		List<Map<String,Object>> a = loginMapper.loginReq(inDTO);
		System.out.println(a);
		
		return test;
	}

}
